<template>
<div id="hbg">
  <div class="home">
    <h1>INTRODUCTION</h1>

    <p> In order to have a good understanding of the factors that affect the market price of a product, one will first need to grasp the meaning of what a market is. A market can be defined as an area over which buyers and sellers negotiate the exchange of some product or related group of products. It must be possible, therefore, for buyers and sellers to communicate with each other and to make meaningful deals over the whole market. Individual markets differ in the degree of competition among the various buyers and sellers. In some cases where the number of buyers and sellers is sufficiently large no one of them will have any appreciable influence on price. This is what is known as a perfectly competitive market. However, for the purposes of this essay we will stick to the concept of a market.

Using the table below we will show how the market price of a product (bread) is affected.    
    </p>  
  </div>

</div>
</template>



<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

h1 {
  color: #fff
}

p {
  color: #fff;
  text-align: justify;
  padding: 5px 0px -10px 10px;
  margin-left: 30px;
  margin-right: 50px;
}

#hbg {
  background: rgba(229, 248, 123, 0.493);
  width: 100%; 
  height: 100%;
  margin-top: 0px;
  display: grid;
  grid-template-rows: auto;
  padding: 0px 0px 0px 0px;
  text-indent: 30px;
}

</style>