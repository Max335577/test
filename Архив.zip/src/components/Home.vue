
<template>
<div id="hbg">
  <div class="home">
    <h1>Hypothesis:</h1>

    <p> There is a positive correlation between gender equality with respect to economic development.

        My Initial Hypothesis

        In the labor market, one may assume that a résumé and credentials are the only significant factor contributing to securing a job in an organization, but that proves to be wrong especially for women. Increasing job opportunities and decent work for women is essential for growth that vital for advancing social and economic development (ADB, 2003).

        After careful observation of countries where social, behavioral, and cultural attributes are the criteria by which individual’s performance is evaluated. I wondered whether or not gender equality had an effect on how well a country’s economy is developing. Based on the mental representation of what we know and expect about girls and women, we tend to be bias in our perception of females being less intelligent, under-skilled and not being clever enough to partake in economic activities. If employers have this type of mindset, I am curious to know under what circumstances gender equality affects the development of a country’s economy.

        The Empirical Evidence

        There are numerous factors that determine the social and economic development of a nation, one of which is gender equality. It is a critical component of economic development, it is a basic right that does not need economic vindication. Gender inequality proves to be the causes of poverty in the society as a whole. Yet gender equality has broad and positive implications for social and economic development.
    </p>  
  </div>

</div>
</template>



<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

h1 {
  color: #fff
}

p {
  color: #fff;
  text-align: justify;
  padding: 5px 0px -10px 10px;
  margin-left: 30px;
  margin-right: 50px;
}

#hbg {
  background: rgba(134, 134, 134, 0.493);
  width: 100%; 
  height: 100%;
  margin-top: 0px;
  display: grid;
  grid-template-rows: auto;
  padding: 0px 0px 0px 0px;
  text-indent: 30px;
}

</style>
